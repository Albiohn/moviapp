import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { JuegoListComponent } from './juego-list/juego-list.component';
import { AccionComponent } from './accion/accion.component';
import { AventuraComponent } from './aventura/aventura.component';
import { RolComponent } from './rol/rol.component';
import { ShooterComponent } from './shooter/shooter.component';
import { TerrorComponent } from './terror/terror.component';
import { RpgComponent } from './rpg/rpg.component'; 



//enrutamiento//
const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: 'juegos',
    component: JuegoListComponent
  },
  {
    path: 'accion',
    component: AccionComponent
  },
  {
    path: 'aventura',
    component: AventuraComponent
  },
  {
    path: 'rol',
    component: RolComponent
  },
  {
    path: 'shooter',
    component: ShooterComponent
  },
  {
    path: 'terror',
    component: TerrorComponent
  },
  {
    path: 'rpg',
    component: RpgComponent
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'game-store',
    loadChildren: () => import('./game-store/game-store.module').then(m => m.GameStorePageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
