import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // Importación de BrowserAnimationsModule
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { JuegoListComponent } from './juego-list/juego-list.component';
import { AccionComponent } from './accion/accion.component'; // Componente AccionComponent
import { AventuraComponent } from './aventura/aventura.component'; // Componente AventuraComponent
import { RolComponent } from './rol/rol.component'; // Componente RolComponent añadido
import { RpgComponent } from './rpg/rpg.component'; // Componente RpgComponent añadido
import { ShooterComponent } from './shooter/shooter.component'; // Componente ShooterComponent añadido
import { TerrorComponent } from './terror/terror.component'; // Componente TerrorComponent añadido

@NgModule({
  declarations: [
    AppComponent,
    JuegoListComponent,
    AccionComponent,
    AventuraComponent,
    RolComponent, // Componente RolComponent añadido
    RpgComponent, // Componente RpgComponent añadido
    ShooterComponent, // Componente ShooterComponent añadido
    TerrorComponent // Componente TerrorComponent añadido
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    FormsModule, // Importación de FormsModule
    HttpClientModule,
    BrowserAnimationsModule // Importación de BrowserAnimationsModule
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
