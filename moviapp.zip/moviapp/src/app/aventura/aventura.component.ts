import { Component, OnInit } from '@angular/core';
import { JuegoService } from '../juego.service';

interface Juego {
  id: number;
  nombre: string;
  categoriaId: number;
}

@Component({
  selector: 'app-aventura',
  templateUrl: './aventura.component.html',
  styleUrls: ['./aventura.component.scss']
})
export class AventuraComponent implements OnInit {
  juegosAventura: any[] = [];

  constructor(private juegoService: JuegoService) { }

  ngOnInit(): void {
    this.getJuegosPorCategoria(2); // Id de la categoria
  }

  getJuegosPorCategoria(categoriaId: number): void {
    this.juegoService.getJuegosPorCategoria(categoriaId)
      .subscribe((juegos: any[]) => {
        this.juegosAventura = juegos;
      });
  }
}
