import { Component, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AnimationController } from '@ionic/angular';

@Component({
  selector: 'app-game-store',
  templateUrl: './game-store.page.html',
  styleUrls: ['./game-store.page.scss']
})
export class GameStorePage implements AfterViewInit {

  constructor(private router: Router, private animationCtrl: AnimationController) {}

  ngAfterViewInit() {
    setTimeout(() => {
      const categoryList = document.querySelector('.category-list') as HTMLElement | null;
      if (categoryList) {
        const animation = this.animationCtrl
          .create()
          .addElement(categoryList)
          .duration(1000)
          .fromTo('opacity', '0', '1');

        animation.play();
      } else {
        console.error('Elemento .category-list no encontrado');
      }
    }, 100); // Ajusta el retraso según sea necesario
  }

  navigateToLogin() {
    this.router.navigate(['/login']); // aqui va la redireccion al login
  }

  navigateToCategory(category: string) {
    this.router.navigate([`/${category}`]);
  }
}
