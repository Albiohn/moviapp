import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss']
})
export class HomePage {
  username!: string;
  name!: string;
  surname!: string;
  educationLevel!: string;
  birthDate!: string | null;

  constructor(private router: Router, private route: ActivatedRoute, private alertController: AlertController) {
    this.route.queryParams.subscribe(params => {
      const navigation = this.router.getCurrentNavigation();
      if (navigation?.extras?.state) {
        this.username = navigation.extras.state['user'];
      }
    });

    // Verificar si el usuario no está autenticado, redirigir a la página de inicio de sesión
    if (!this.username) {
      this.router.navigateByUrl('/login');
    }
  }

  clearForm() {
    this.name = '';
    this.surname = '';
    this.educationLevel = '';
    this.birthDate = null;
  }

  async showData() {
    let birthDateStr = '';
    if (this.birthDate) {
      const dateParts = this.birthDate.split('-');
      const year = dateParts[0];
      const month = dateParts[1];
      const day = dateParts[2].split('T')[0];
      birthDateStr = `${day}/${month}/${year}`;
    }

    const alert = await this.alertController.create({
      header: 'Información',
      message: `
        Nombre: ${this.name},
        Apellido: ${this.surname},
        Nivel de Educación: ${this.educationLevel},
        Fecha de Nacimiento: ${birthDateStr}.
      `,
      buttons: ['OK']
    });
    await alert.present();
  }
}
