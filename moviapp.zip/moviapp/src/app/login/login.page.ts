import { Component, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AnimationController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements AfterViewInit {
  loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private animationCtrl: AnimationController
  ) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(8)]],
      password: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(12)]],
    });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      const formContainer = document.querySelector('.form-container') as HTMLElement | null;
      if (formContainer) {
        const animation = this.animationCtrl
          .create()
          .addElement(formContainer)
          .duration(1000)
          .fromTo('opacity', '0', '1');

        animation.play();
      } else {
        console.error('Elemento .form-container no encontrado');
      }
    }, 100); // Ajusta el retraso según sea necesario
  }

  async onLogin() {
    if (this.loginForm.valid) {
      const navigationExtras = {
        state: {
          user: this.loginForm.value.username,
        },
      };
      await this.router.navigateByUrl('/game-store', navigationExtras);
    }
  }
}
