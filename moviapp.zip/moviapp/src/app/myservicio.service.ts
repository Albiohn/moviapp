import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private user = new BehaviorSubject(null);

  registerUser(username: string, name: string, surname: string, educationLevel: string, birthDate: string) {
    // Aquí deberías conectar con tu backend para registrar el usuario.
    // Por ahora, vamos a simularlo con un objeto simple.
    this.user.next({ username, name, surname, educationLevel, birthDate });
  }

  login(username: string) {
    // Aquí deberías verificar las credenciales del usuario con tu backend.
    // Por ahora, vamos a comprobar si las credenciales coinciden con el usuario que hemos registrado.
    const user = this.user.value;
    if (user && user.username === username) {
      return true;
    } else {
      return false;
    }
  }
}
