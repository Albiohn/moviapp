import { Component, OnInit } from '@angular/core';
import { JuegoService } from '../juego.service'; 

interface Juego {
  id: number;
  nombre: string;
  categoriaId: number;
}

@Component({
  selector: 'app-rol',
  templateUrl: './rol.component.html',
  styleUrls: ['./rol.component.scss'],
})
export class RolComponent implements OnInit {
  juegosRol: any[] = []; // Define la propiedad juegosRol aquí

  constructor(private juegoService: JuegoService) { }

  ngOnInit(): void {
    this.getJuegosPorCategoria(3); // Id de la categoria
  }

  getJuegosPorCategoria(categoriaId: number): void {
    this.juegoService.getJuegosPorCategoria(categoriaId)
      .subscribe((juegos: any[]) => {
        this.juegosRol = juegos;
      });
  }
}
