import { Component, OnInit } from '@angular/core';
import { JuegoService } from '../juego.service';

interface Juego {
  id: number;
  nombre: string;
  categoriaId: number;
}

@Component({
  selector: 'app-rpg',
  templateUrl: './rpg.component.html',
  styleUrls: ['./rpg.component.scss'],
})
export class RpgComponent implements OnInit {
  juegosRpg: any[] = [];

  constructor(private juegoService: JuegoService) { }

  ngOnInit(): void {
    this.getJuegosPorCategoria(4); // Id de la categoria
  }

  getJuegosPorCategoria(categoriaId: number): void {
    this.juegoService.getJuegosPorCategoria(categoriaId)
      .subscribe((juegos: any[]) => {
        this.juegosRpg = juegos;
      });
  }
}
