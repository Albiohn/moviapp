import { Component, OnInit } from '@angular/core';
import { JuegoService } from '../juego.service';


interface Juego {
  id: number;
  nombre: string;
  categoriaId: number;
}

@Component({
  selector: 'app-shooter',
  templateUrl: './shooter.component.html',
  styleUrls: ['./shooter.component.scss'],
})
export class ShooterComponent implements OnInit {
  juegosShooter: any[] = [];

  constructor(private juegoService: JuegoService) { }

  ngOnInit(): void {
    this.getJuegosPorCategoria(5); // Id de la categoria
  }

  getJuegosPorCategoria(categoriaId: number): void {
    this.juegoService.getJuegosPorCategoria(categoriaId)
      .subscribe((juegos: any[]) => {
        this.juegosShooter = juegos;
      });
  }
}
