import { Component, OnInit } from '@angular/core';
import { JuegoService } from '../juego.service';


interface Juego {
  id: number;
  nombre: string;
  categoriaId: number;
}

@Component({
  selector: 'app-terror',
  templateUrl: './terror.component.html',
  styleUrls: ['./terror.component.scss'],
})
export class TerrorComponent implements OnInit {
  juegosTerror: any[] = [];

  constructor(private juegoService: JuegoService) { }

  ngOnInit(): void {
    this.getJuegosPorCategoria(6); // Id de la categoria
  }

  getJuegosPorCategoria(categoriaId: number): void {
    this.juegoService.getJuegosPorCategoria(categoriaId)
      .subscribe((juegos: any[]) => {
        this.juegosTerror = juegos;
      });
  }
}
